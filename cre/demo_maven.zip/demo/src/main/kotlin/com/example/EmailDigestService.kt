package com.example

interface EmailDigestService {

    fun sendEmail(email: String)

}